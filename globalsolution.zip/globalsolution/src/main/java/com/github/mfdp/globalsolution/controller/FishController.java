package com.github.mfdp.globalsolution.controller;

import java.util.List;

import com.github.mfdp.globalsolution.model.Peixes;
import com.github.mfdp.globalsolution.reopository.FishRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("peixes")
public class FishController {

    @Autowired
    private FishRepository fishRepository;



    @GetMapping()
    public String list(Model model) {
        List<Peixes> peixes = fishRepository.findAll(Sort.by(Sort.Direction.ASC, "nome"));
        model.addAttribute("peixes", peixes);
        return "peixe/list";
    }

    @GetMapping("add")
    public String create(Model model) {

        model.addAttribute("peixe", new Peixes());
        return "peixe/form";
    }

    @PostMapping("save")
    public String save(@ModelAttribute Peixes fish) {

        fishRepository.save(fish);
        return "redirect:/peixes";
    }

    @GetMapping("update/{id}")
    public String update(@PathVariable Long id, Model model) {
        Peixes fish = fishRepository.findById(id).orElse(new Peixes());

        model.addAttribute("peixe", fish);
        return "peixe/form";
    }

    @GetMapping("delete/{id}")
    public String delete(@PathVariable Long id) {
        fishRepository.deleteById(id);
        return "redirect:/peixes";
    }

}