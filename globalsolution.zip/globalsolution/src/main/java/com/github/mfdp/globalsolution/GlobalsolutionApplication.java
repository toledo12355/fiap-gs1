package com.github.mfdp.globalsolution;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GlobalsolutionApplication {

	public static void main(String[] args) {
		SpringApplication.run(GlobalsolutionApplication.class, args);
	}

}
