package com.github.mfdp.globalsolution;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GlobalsolutionApplicationTests {

	@Test
	void contextLoads() {
	}

}
